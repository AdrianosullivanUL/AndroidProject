package com.example.maryc.egtcalc;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.GregorianCalendar;

public class MainActivity extends AppCompatActivity {
    private TextView mESNdetailsTextView,mTSNdetailsTextView;
    private TextView mCSNdetailsTextView, mThrust_1TextView,mEGT_1TextView,mWEGT_1TextView;
    //private TextView mThrust_2TextView,mEGT_2TextView,mWEGT_2TextView;
    //private TextView mThrust_3TextView,mEGT_3TextView,mWEGT_3TextView;
   // private TextView mThrust_4TextView,mEGT_4TextView,mWEGT_4TextView;
   // private TextView mThrust_5TextView,mEGT_5TextView,mWEGT_5TextView;


    private egt_calc mCurrentEgt_calc;
    //private Item mClearedItem;
   // private ArrayList <Item> mItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mESNdetailsTextView = findViewById(R.id.ESNdetails);
        mTSNdetailsTextView = findViewById(R.id.TSNdetails);
        mThrust_1TextView = findViewById(R.id.Thrust_1);
        mEGT_1TextView = findViewById(R.id.EGT_1);
        mWEGT_1TextView = findViewById(R.id.WEGT_1);
        //mThrust_2TextView = findViewById(R.id.Thrust_2);
        //mEGT_2TextView = findViewById(R.id.EGT_2);
        //mWEGT_2TextView = findViewById(R.id.WEGT_2);
       // mThrust_3TextView = findViewById(R.id.Thrust_3);
       // mEGT_3TextView = findViewById(R.id.EGT_3);
        //mWEGT_3TextView = findViewById(R.id.WEGT_3);
       // mThrust_4TextView = findViewById(R.id.Thrust_4);
        // = findViewById(R.id.EGT_4);
       // mWEGT_4TextView = findViewById(R.id.WEGT_4);
        //mThrust_5TextView = findViewById(R.id.Thrust_5);
        //mEGT_5TextView = findViewById(R.id.EGT_5);
        //mWEGT_5TextView = findViewById(R.id.WEGT_5);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertEGT_Calc();
            }
        });
    }

    private void insertEGT_Calc(){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        View view = getLayoutInflater().inflate(R.layout.dialog_add, null, false);
        builder.setView(view);
        final EditText ESN = (EditText) view.findViewById(R.id.edit_ESN);
        final EditText TSN = (EditText) view.findViewById(R.id.edit_TSN);
        final EditText CSN= (EditText) view.findViewById(R.id.edit_CSN);
        final CalendarView deliveryDateView = (CalendarView) view.findViewById(R.id.calendar_view);
        final GregorianCalendar calendar = new GregorianCalendar();
        deliveryDateView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
           public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                calendar.set(year, month, dayOfMonth);
           }
        });
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
           public void onClick(DialogInterface dialog, int which) {
              // String ESN = ESN.getText().toString();
              // int TSN = Integer.parseInt(TSN.getText().toString());
              // int CSN = Integer.parseInt(CSN.getText().toString());
              // mCurrentEgt_Calc = new Egt_calc(ESN, TSN,CSN,calendar);
              // mEgt_Calc.add(mEGT_Calc);
              // showCurrentEgtCalc();
            }


       });
        builder.setNegativeButton(android.R.string.cancel, null);
       builder.create().show();

    }



    private void showCurrentEgt_Calc() {
        mESNdetailsTextView.setText(mCurrentEgt_calc.getmESN());
        //mTSNdetailsTextView.setText(getString(R.string.resultTSN, mCurrentEgt_calc.getmTSN()));
       // mCSNdetailsTextView.setText(getString(R.string.resultCSN, mCurrentEgt_calc.getmCSN()));

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
